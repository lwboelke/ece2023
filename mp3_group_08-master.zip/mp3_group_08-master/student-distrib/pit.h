#ifndef PIT_H
#define PIT_H

// Function prototypes for the PIT

/* Initializes the PIT controller */
void pit_init();

/* Handler for the PIT*/
void pit_handler();

#endif
