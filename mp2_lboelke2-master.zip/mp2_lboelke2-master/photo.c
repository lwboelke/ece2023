/*									tab:8
 *
 * photo.c - photo display functions
 *
 * "Copyright (c) 2011 by Steven S. Lumetta."
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE AUTHOR OR THE UNIVERSITY OF ILLINOIS BE LIABLE TO 
 * ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL 
 * DAMAGES ARISING OUT  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, 
 * EVEN IF THE AUTHOR AND/OR THE UNIVERSITY OF ILLINOIS HAS BEEN ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE AUTHOR AND THE UNIVERSITY OF ILLINOIS SPECIFICALLY DISCLAIM ANY 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE 
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND NEITHER THE AUTHOR NOR
 * THE UNIVERSITY OF ILLINOIS HAS ANY OBLIGATION TO PROVIDE MAINTENANCE, 
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Author:	    Steve Lumetta
 * Version:	    3
 * Creation Date:   Fri Sep  9 21:44:10 2011
 * Filename:	    photo.c
 * History:
 *	SL	1	Fri Sep  9 21:44:10 2011
 *		First written (based on mazegame code).
 *	SL	2	Sun Sep 11 14:57:59 2011
 *		Completed initial implementation of functions.
 *	SL	3	Wed Sep 14 21:49:44 2011
 *		Cleaned up code for distribution.
 */


#include <string.h>

#include "assert.h"
#include "modex.h"
#include "photo.h"
#include "photo_headers.h"
#include "world.h"


/* types local to this file (declared in types.h) */

/* 
 * A room photo.  Note that you must write the code that selects the
 * optimized palette colors and fills in the pixel data using them as 
 * well as the code that sets up the VGA to make use of these colors.
 * Pixel data are stored as one-byte values starting from the upper
 * left and traversing the top row before returning to the left of
 * the second row, and so forth.  No padding should be used.
 */
struct photo_t {
    photo_header_t hdr;			/* defines height and width */
    uint8_t        palette[192][3];     /* optimized palette colors */
    uint8_t*       img;                 /* pixel data               */
};

/* 
 * An object image.  The code for managing these images has been given
 * to you.  The data are simply loaded from a file, where they have 
 * been stored as 2:2:2-bit RGB values (one byte each), including 
 * transparent pixels (value OBJ_CLR_TRANSP).  As with the room photos, 
 * pixel data are stored as one-byte values starting from the upper 
 * left and traversing the top row before returning to the left of the 
 * second row, and so forth.  No padding is used.
 */
struct image_t {
    photo_header_t hdr;			/* defines height and width */
    uint8_t*       img;                 /* pixel data               */
};

/*
 * An octree node. Each has an int value to hold its RRRRR:GGGGGG:BBBBB value,
 * an int frequency to store the number of pixels that share the bits of the
 * corresponding level (for example, RRRR:GGGG:BBBB for level four), ints
 * r, g, and b to store a running sum of the last bits of red and blue pixel
 * values and last 2 of green (to be used in level four averaging), as well as
 * ints r_two, g_two, and b_two to hold a running sum of the last 3 bits of
 * red and blue pixel values, and last 3 bits of green (to be used in level two
 * averaging).
 */
struct oct_node_t {
	int value;	/* RRRRR:GGGGGG:BBBBB value */
	int frequency;	/* frequency among the pixels */
	int r;	/* running sum of last red bits */
	int g;	/* running sum of last 2 green bits */
	int b;	/* running sum of last blue bits */
	int r_two;	/* running sum of last 3 red bits */
	int g_two;	/* running sum of last 4 green bits */
	int b_two;	/* running sum of last 3 blue bits */ 
};

/* file-scope variables */

/* 
 * The room currently shown on the screen.  This value is not known to 
 * the mode X code, but is needed when filling buffers in callbacks from 
 * that code (fill_horiz_buffer/fill_vert_buffer).  The value is set 
 * by calling prep_room.
 */
static const room_t* cur_room = NULL; 

/* 
 * fill_horiz_buffer
 *   DESCRIPTION: Given the (x,y) map pixel coordinate of the leftmost 
 *                pixel of a line to be drawn on the screen, this routine 
 *                produces an image of the line.  Each pixel on the line
 *                is represented as a single byte in the image.
 *
 *                Note that this routine draws both the room photo and
 *                the objects in the room.
 *
 *   INPUTS: (x,y) -- leftmost pixel of line to be drawn 
 *   OUTPUTS: buf -- buffer holding image data for the line
 *   RETURN VALUE: none
 *   SIDE EFFECTS: none
 */
void
fill_horiz_buffer (int x, int y, unsigned char buf[SCROLL_X_DIM])
{
    int            idx;   /* loop index over pixels in the line          */ 
    object_t*      obj;   /* loop index over objects in the current room */
    int            imgx;  /* loop index over pixels in object image      */ 
    int            yoff;  /* y offset into object image                  */ 
    uint8_t        pixel; /* pixel from object image                     */
    const photo_t* view;  /* room photo                                  */
    int32_t        obj_x; /* object x position                           */
    int32_t        obj_y; /* object y position                           */
    const image_t* img;   /* object image                                */

    /* Get pointer to current photo of current room. */
    view = room_photo (cur_room);

    /* Loop over pixels in line. */
    for (idx = 0; idx < SCROLL_X_DIM; idx++) {
        buf[idx] = (0 <= x + idx && view->hdr.width > x + idx ?
		    view->img[view->hdr.width * y + x + idx] : 0);
    }

    /* Loop over objects in the current room. */
    for (obj = room_contents_iterate (cur_room); NULL != obj;
    	 obj = obj_next (obj)) {
	obj_x = obj_get_x (obj);
	obj_y = obj_get_y (obj);
	img = obj_image (obj);

        /* Is object outside of the line we're drawing? */
	if (y < obj_y || y >= obj_y + img->hdr.height ||
	    x + SCROLL_X_DIM <= obj_x || x >= obj_x + img->hdr.width) {
	    continue;
	}

	/* The y offset of drawing is fixed. */
	yoff = (y - obj_y) * img->hdr.width;

	/* 
	 * The x offsets depend on whether the object starts to the left
	 * or to the right of the starting point for the line being drawn.
	 */
	if (x <= obj_x) {
	    idx = obj_x - x;
	    imgx = 0;
	} else {
	    idx = 0;
	    imgx = x - obj_x;
	}

	/* Copy the object's pixel data. */
	for (; SCROLL_X_DIM > idx && img->hdr.width > imgx; idx++, imgx++) {
	    pixel = img->img[yoff + imgx];

	    /* Don't copy transparent pixels. */
	    if (OBJ_CLR_TRANSP != pixel) {
		buf[idx] = pixel;
	    }
	}
    }
}


/* 
 * fill_vert_buffer
 *   DESCRIPTION: Given the (x,y) map pixel coordinate of the top pixel of 
 *                a vertical line to be drawn on the screen, this routine 
 *                produces an image of the line.  Each pixel on the line
 *                is represented as a single byte in the image.
 *
 *                Note that this routine draws both the room photo and
 *                the objects in the room.
 *
 *   INPUTS: (x,y) -- top pixel of line to be drawn 
 *   OUTPUTS: buf -- buffer holding image data for the line
 *   RETURN VALUE: none
 *   SIDE EFFECTS: none
 */
void
fill_vert_buffer (int x, int y, unsigned char buf[SCROLL_Y_DIM])
{
    int            idx;   /* loop index over pixels in the line          */ 
    object_t*      obj;   /* loop index over objects in the current room */
    int            imgy;  /* loop index over pixels in object image      */ 
    int            xoff;  /* x offset into object image                  */ 
    uint8_t        pixel; /* pixel from object image                     */
    const photo_t* view;  /* room photo                                  */
    int32_t        obj_x; /* object x position                           */
    int32_t        obj_y; /* object y position                           */
    const image_t* img;   /* object image                                */

    /* Get pointer to current photo of current room. */
    view = room_photo (cur_room);

    /* Loop over pixels in line. */
    for (idx = 0; idx < SCROLL_Y_DIM; idx++) {
        buf[idx] = (0 <= y + idx && view->hdr.height > y + idx ?
		    view->img[view->hdr.width * (y + idx) + x] : 0);
    }

    /* Loop over objects in the current room. */
    for (obj = room_contents_iterate (cur_room); NULL != obj;
    	 obj = obj_next (obj)) {
	obj_x = obj_get_x (obj);
	obj_y = obj_get_y (obj);
	img = obj_image (obj);

        /* Is object outside of the line we're drawing? */
	if (x < obj_x || x >= obj_x + img->hdr.width ||
	    y + SCROLL_Y_DIM <= obj_y || y >= obj_y + img->hdr.height) {
	    continue;
	}

	/* The x offset of drawing is fixed. */
	xoff = x - obj_x;

	/* 
	 * The y offsets depend on whether the object starts below or 
	 * above the starting point for the line being drawn.
	 */
	if (y <= obj_y) {
	    idx = obj_y - y;
	    imgy = 0;
	} else {
	    idx = 0;
	    imgy = y - obj_y;
	}

	/* Copy the object's pixel data. */
	for (; SCROLL_Y_DIM > idx && img->hdr.height > imgy; idx++, imgy++) {
	    pixel = img->img[xoff + img->hdr.width * imgy];

	    /* Don't copy transparent pixels. */
	    if (OBJ_CLR_TRANSP != pixel) {
		buf[idx] = pixel;
	    }
	}
    }
}


/* 
 * image_height
 *   DESCRIPTION: Get height of object image in pixels.
 *   INPUTS: im -- object image pointer
 *   OUTPUTS: none
 *   RETURN VALUE: height of object image im in pixels
 *   SIDE EFFECTS: none
 */
uint32_t 
image_height (const image_t* im)
{
    return im->hdr.height;
}


/* 
 * image_width
 *   DESCRIPTION: Get width of object image in pixels.
 *   INPUTS: im -- object image pointer
 *   OUTPUTS: none
 *   RETURN VALUE: width of object image im in pixels
 *   SIDE EFFECTS: none
 */
uint32_t 
image_width (const image_t* im)
{
    return im->hdr.width;
}

/* 
 * photo_height
 *   DESCRIPTION: Get height of room photo in pixels.
 *   INPUTS: p -- room photo pointer
 *   OUTPUTS: none
 *   RETURN VALUE: height of room photo p in pixels
 *   SIDE EFFECTS: none
 */
uint32_t 
photo_height (const photo_t* p)
{
    return p->hdr.height;
}


/* 
 * photo_width
 *   DESCRIPTION: Get width of room photo in pixels.
 *   INPUTS: p -- room photo pointer
 *   OUTPUTS: none
 *   RETURN VALUE: width of room photo p in pixels
 *   SIDE EFFECTS: none
 */
uint32_t 
photo_width (const photo_t* p)
{
    return p->hdr.width;
}


/* 
 * prep_room
 *   DESCRIPTION: Prepare a new room for display.  You might want to set
 *                up the VGA palette registers according to the color
 *                palette that you chose for this room.
 *   INPUTS: r -- pointer to the new room
 *   OUTPUTS: none
 *   RETURN VALUE: none
 *   SIDE EFFECTS: changes recorded cur_room for this file
 */
void
prep_room (const room_t* r)
{
    /* Record the current room. */
    cur_room = r;
	photo_t* p = room_photo(r);	/* get the photo for the current room */
	set_palette(p->palette);	/* set the palette for the room's photo */
}


/* 
 * read_obj_image
 *   DESCRIPTION: Read size and pixel data in 2:2:2 RGB format from a
 *                photo file and create an image structure from it.
 *   INPUTS: fname -- file name for input
 *   OUTPUTS: none
 *   RETURN VALUE: pointer to newly allocated photo on success, or NULL
 *                 on failure
 *   SIDE EFFECTS: dynamically allocates memory for the image
 */
image_t*
read_obj_image (const char* fname)
{
    FILE*    in;		/* input file               */
    image_t* img = NULL;	/* image structure          */
    uint16_t x;			/* index over image columns */
    uint16_t y;			/* index over image rows    */
    uint8_t  pixel;		/* one pixel from the file  */

    /* 
     * Open the file, allocate the structure, read the header, do some
     * sanity checks on it, and allocate space to hold the image pixels.
     * If anything fails, clean up as necessary and return NULL.
     */
    if (NULL == (in = fopen (fname, "r+b")) ||
	NULL == (img = malloc (sizeof (*img))) ||
	NULL != (img->img = NULL) || /* false clause for initialization */
	1 != fread (&img->hdr, sizeof (img->hdr), 1, in) ||
	MAX_OBJECT_WIDTH < img->hdr.width ||
	MAX_OBJECT_HEIGHT < img->hdr.height ||
	NULL == (img->img = malloc 
		 (img->hdr.width * img->hdr.height * sizeof (img->img[0])))) {
	if (NULL != img) {
	    if (NULL != img->img) {
	        free (img->img);
	    }
	    free (img);
	}
	if (NULL != in) {
	    (void)fclose (in);
	}
	return NULL;
    }

    /* 
     * Loop over rows from bottom to top.  Note that the file is stored
     * in this order, whereas in memory we store the data in the reverse
     * order (top to bottom).
     */
    for (y = img->hdr.height; y-- > 0; ) {

	/* Loop over columns from left to right. */
	for (x = 0; img->hdr.width > x; x++) {

	    /* 
	     * Try to read one 8-bit pixel.  On failure, clean up and 
	     * return NULL.
	     */
	    if (1 != fread (&pixel, sizeof (pixel), 1, in)) {
		free (img->img);
		free (img);
	        (void)fclose (in);
		return NULL;
	    }

	    /* Store the pixel in the image data. */
	    img->img[img->hdr.width * y + x] = pixel;
	}
    }

    /* All done.  Return success. */
    (void)fclose (in);
    return img;
}


/* 
 * read_photo
 *   DESCRIPTION: Read size and pixel data in 5:6:5 RGB format from a
 *                photo file and create a photo structure from it.
 *                Code provided simply maps to 2:2:2 RGB.  You must
 *                replace this code with palette color selection, and
 *                must map the image pixels into the palette colors that
 *                you have defined.
 *   INPUTS: fname -- file name for input
 *   OUTPUTS: none
 *   RETURN VALUE: pointer to newly allocated photo on success, or NULL
 *                 on failure
 *   SIDE EFFECTS: dynamically allocates memory for the photo
 */
photo_t*
read_photo (const char* fname)
{
    FILE*    in;	/* input file               */
    photo_t* p = NULL;	/* photo structure          */
    uint16_t x;		/* index over image columns */
    uint16_t y;		/* index over image rows    */
    uint16_t pixel;	/* one pixel from the file  */
	int num_level_four = 4096;	/* number of level four octree nodes */
	int num_level_two = 64;	/* number of level two octree nodes */
	int num_ints_struct = 8;	/* number of ints in the octree node struct */
	int shift_red = 11;	/* number to shift 16 bit value by to get red bits */
	int shift_green = 5;	/* number to shift 16 bit value by to get green bits */
	int level_four_pal = 128;	/* number of palette values that come from level four nodes */
	int index_offset = 64;	/* index to offset the vga palette from */
	int palette_size = 192;	/* number of palette values we must set */

	/* populate an array with level four octree nodes */
	struct oct_node_t level_four[num_level_four];
	populate_level_four(level_four);

	/* populate an array with level two octree nodes */
	struct oct_node_t level_two[num_level_two];
	populate_level_two(level_two);

    /* 
     * Open the file, allocate the structure, read the header, do some
     * sanity checks on it, and allocate space to hold the photo pixels.
     * If anything fails, clean up as necessary and return NULL.
     */
    if (NULL == (in = fopen (fname, "r+b")) ||
	NULL == (p = malloc (sizeof (*p))) ||
	NULL != (p->img = NULL) || /* false clause for initialization */
	1 != fread (&p->hdr, sizeof (p->hdr), 1, in) ||
	MAX_PHOTO_WIDTH < p->hdr.width ||
	MAX_PHOTO_HEIGHT < p->hdr.height ||
	NULL == (p->img = malloc 
		 (p->hdr.width * p->hdr.height * sizeof (p->img[0])))) {
	if (NULL != p) {
	    if (NULL != p->img) {
	        free (p->img);
	    }
	    free (p);
	}
	if (NULL != in) {
	    (void)fclose (in);
	}
	return NULL;
    }

    /* 
     * Loop over rows from bottom to top.  Note that the file is stored
     * in this order, whereas in memory we store the data in the reverse
     * order (top to bottom).
     */
    for (y = p->hdr.height; y-- > 0; ) {

	/* Loop over columns from left to right. */
	for (x = 0; p->hdr.width > x; x++) {

	    /* 
	     * Try to read one 16-bit pixel.  On failure, clean up and 
	     * return NULL.
	     */
	    if (1 != fread (&pixel, sizeof (pixel), 1, in)) {
		free (p->img);
		free (p);
	        (void)fclose (in);
		return NULL;

	    }

		/* update the frequency and running sums of the level four node corresponding to the current pixel */
		level_four[value_to_index(pixel)].frequency++;
		level_four[value_to_index(pixel)].r += ((pixel >> shift_red) & 1);
		level_four[value_to_index(pixel)].g += ((pixel >> shift_green) & 3);
		level_four[value_to_index(pixel)].b += (pixel & 1);
		level_four[value_to_index(pixel)].r_two += ((pixel >> shift_red) & 7);
		level_four[value_to_index(pixel)].g_two += ((pixel >> shift_green) & 15);
		level_four[value_to_index(pixel)].b_two += (pixel & 7);

	    /* 
	     * 16-bit pixel is coded as 5:6:5 RGB (5 bits red, 6 bits green,
	     * and 6 bits blue).  We change to 2:2:2, which we've set for the
	     * game objects.  You need to use the other 192 palette colors
	     * to specialize the appearance of each photo.
	     *
	     * In this code, you need to calculate the p->palette values,
	     * which encode 6-bit RGB as arrays of three uint8_t's.  When
	     * the game puts up a photo, you should then change the palette 
	     * to match the colors needed for that photo.
	     */
	    p->img[p->hdr.width * y + x] = (((pixel >> 14) << 4) |
					    (((pixel >> 9) & 0x3) << 2) |
					    ((pixel >> 3) & 0x3));
	}
    }

	qsort(level_four, num_level_four, sizeof(int) * num_ints_struct, comp);	/* sort the array of level four nodes by highest to lowest frequency */

	int i = 0;
	int r_avg = 0;	/* to hold the average red value for the current node */
	int g_avg = 0;	/* to hold the average green value for the current node */
	int b_avg = 0;	/* to hold the average blue value for the current node */
	/* loop through the first 128 most frequent level four octree nodes */
	for (i = 0; i < level_four_pal; i++) {
		/* check if the frequency is non-zero (to avoid dividing by zero) */
		if (level_four[i].frequency != 0) {
			/* if it is non-zero, calculate the averages using the running sums and frequency */
			r_avg = level_four[i].r / level_four[i].frequency;
			int r_val = (((level_four[i].value >> shift_red) & 0x1E) | (r_avg & 1));
			r_avg = r_val;
			g_avg = level_four[i].g / level_four[i].frequency;
			int g_val = (((level_four[i].value >> shift_green) & 0x3C) | (g_avg & 3));
			g_avg = g_val;
			b_avg = level_four[i].b / level_four[i].frequency;
			int b_val = (((level_four[i].value) & 0x1E) | (b_avg & 1));
			b_avg = b_val;
		}
		else {
			/* if the frequency is zero, set the averages to the original level four values */
			r_avg = (((level_four[i].value >> shift_red) & 0x1F));
			g_avg = ((level_four[i].value >> shift_green) & 0x3F);
			b_avg = ((level_four[i].value & 0x1F));
		}
		/* set the first 128 palette values to the calculated averages */
		p->palette[i][0] = ((r_avg & 0x1F) << 1);
		p->palette[i][1] = (g_avg & 0x3F);
		p->palette[i][2] = ((b_avg & 0x1F) << 1);
	}

	/* loop through the remaining octree nodes in the level four array */
	for (i = level_four_pal; i < num_level_four; i++) {
		/* calculate the corresponding index into the level two array by getting RR:GG:BB */
		int first_red = ((level_four[i].value >> 10) & 0x30);
		int first_green = ((level_four[i].value >> 7) & 0x0C);
		int first_blue = ((level_four[i].value >> 3) & 3);
		int idx = (first_red | first_green | first_blue);
		/* update the frequency and running sums for the corresponding level two node based on level four node */
		level_two[idx].r_two += level_four[i].r_two;
		level_two[idx].g_two += level_four[i].g_two;
		level_two[idx].b_two += level_four[i].b_two;
		level_two[idx].frequency += level_four[i].frequency;
	}

	/* iterate through the nodes in the level two array and set the last 64 palette values to the calculated averages */
	for (i = 0; i < num_level_two; i++) {
		/* check if the frequency is non-zero (to avoid dividing by zero) */
		if (level_two[i].frequency != 0) {
			int r_avg = level_two[i].r_two / level_two[i].frequency;
			int r_val = (((level_two[i].value >> shift_red) & 0x18) | (r_avg & 7));
			/* set the red palette value to the calculated red average */
			p->palette[level_four_pal + i][0] = (r_val << 1);
			int g_avg = level_two[i].g_two / level_two[i].frequency;
			int g_val = (((level_two[i].value >> shift_green) & 0x30) | (g_avg & 0x0F));
			/* set the green palette value to the calculated green average */
			p->palette[level_four_pal + i][1] = g_val;
			int b_avg = level_two[i].b_two / level_two[i].frequency;
			int b_val = ((level_two[i].value & 0x18) | (b_avg & 7));
			/* set the blue palette value to the calculated blue average */
			p->palette[level_four_pal + i][2] = (b_val << 1);
		}
		else {
			/* if the frequency is zero, set the palette value to the original level two value */
			p->palette[level_four_pal + i][0] = (((level_two[i].value >> shift_red) & 0x1F) << 1);
			p->palette[level_four_pal + i][1] = ((level_two[i].value >> shift_green) & 0x3F);
			p->palette[level_four_pal + i][2] = ((level_two[i].value & 0x1F) << 1);
		}
	}
	fseek(in, sizeof(p->hdr), SEEK_SET);	/* reset the pointer to the beggining of the file */
	x = 0;	/* x value of the pixel */
	y = 0;	/* y value of the pixel */
	/* iterate through the pixels in the file */
    for (y = p->hdr.height; y-- > 0; ) {
		for (x = 0; p->hdr.width > x; x++) {
			/* read the current pixel */
			if (1 != fread (&pixel, sizeof (pixel), 1, in)) {
				/* if the read failed, free the memory and return NULL */
				free (p->img);
				free (p);
	        	(void)fclose (in);
				return NULL;
	    	}
			int r = ((pixel >> 12) & 0x0F);	/* get the first four red bits of the pixel */
			int g = ((pixel >> 7) & 0x0F);	/* get the first four green bits of the pixel */
			int b = ((pixel >> 1) & 0x0F);	/* get the first four blue bits of the pixel */
			int flag = 0;	/* flag to check if the pixel was caught by first 128 palette values */
			int i = 0;
			/* loop through the first 128 palette values from level four */
			for (i = 0; i < level_four_pal; i++) {
				/* check if the current level four palette value matches the pixel in the first four bits of each color value */
				if (r == ((p->palette[i][0] >> 2) & 0x0F) && g == ((p->palette[i][1] >> 2) & 0x0F) && b == ((p->palette[i][2] >> 2) & 0x0F)) {
					p->img[p->hdr.width * y + x] = i + index_offset;	/* if it does, set the value at the current address of img to the palette index offset by 64 */
					flag = 1;	/* set the flag to one so the level two values are not checked */
					break;
				}
			}
			/* check if the pixel was not caught by first 128 values */
			if (flag == 0) {
				int i = 0;
				int r_two = ((pixel >> 14) & 3);	/* get the first two red bits of the pixel */ 
				int g_two = ((pixel >> 9) & 3);	/* get the first two green bits of the pixel */
				int b_two = ((pixel >> 3) & 3);	/* get the first two blue bits of the pixel */
				/* iterate through the remaining 64 palette values from level two */
				for (i = level_four_pal; i < palette_size; i++) {
					/* check if the current level two palette value matches the pixel in the first two bits of each color value */
					if (r_two == ((p->palette[i][0] >> 4) & 3) && g_two == ((p->palette[i][1] >> 4) & 3) && b_two == ((p->palette[i][2] >> 4) & 3)) {
						p->img[p->hdr.width * y + x] = i + index_offset;	/* if it does, set the value at the current address of img to the palette index offset by 64 */
						break;
					}
				}
			}
		}
	}
    /* All done.  Return success. */
    (void)fclose (in);
    return p;
}

/* 
 * get_value_four
 *   DESCRIPTION: Given the index of an array of level four octree nodes, this function
 *				  calculates and returns the corresponding value of the level four octree
 *				  node at that index.
 *   INPUTS: index -- index of the level four octree node whose value is to be calculated
 *   OUTPUTS: none
 *   RETURN VALUE: the RRRRR:GGGGGG:BBBBB value corresponding to the RRRR:GGGG:BBBB input index
 *   SIDE EFFECTS: none
 */
int get_value_four(int index) {
	int num_level_four = 4096;	/* number of level four octree nodes */
	/* make sure the input is within the range of level four octree node indexes */
	if (index >= 0 && index < num_level_four) {
		/* if it is, calculate value */
		int b = index % 2;	/* set b to the lowest bit of the index */
		index /= 2;	/* divide index by two to shift */
		int i = 0;
		/* iterate through the remaining three blue bits of the index so b holds the low four bits */
		for (i = 1; i < 4; i++) {
			b = b | ((index % 2) << i);
			index /= 2;
		}
		int g = index % 2;	/* set g to the fifth lowest bit of the index */
		index /= 2;	/* divide index by two to shift */
		/* iterate through the remaining three green bits of the index so g holds the middle four bits */
		for (i = 1; i < 4; i++) {
			g = g | ((index % 2) << i);
			index /= 2;
		}
		int r = index % 2;	/* set r to the ninth lowest bit of the index */
		index /= 2;	/* divide index by two to shift */
		/* iterate through the remaining three red bits to the index so r holds the highest four bits */
		for (i = 1; i < 4; i++) {
			r = r | ((index % 2) << i);
			index /= 2;
		}
		return ((b << 1) | (g << 7) | (r << 12)); /* return the values ORed together to get RRRR0:GGGG00:BBBB0 */
	}
	else {
		/* if the input is not in range, return -1 */
		return -1;
	}
}

/* 
 * get_value_two
 *   DESCRIPTION: Given the index of an array of level two octree nodes, this function
 *				  calculates and returns the corresponding value of the level two octree
 *				  node at that index.
 *   INPUTS: index -- index of the level two octree node whose value is to be calculated
 *   OUTPUTS: none
 *   RETURN VALUE: the RRRRR:GGGGGG:BBBBB value corresponding to the RR:GG:BB input index
 *   SIDE EFFECTS: none
 */
int get_value_two(int index) {
	int num_level_two = 64;	/* number of level two octree nodes */
	/* make sure the input is within the range of level two octree node indexes */
	if (index >= 0 && index < num_level_two) {
		int b = index % 2;	/* set b to the lowest bit of the index */
		index /= 2;	/* divide index by two to shift */
		int i = 0;
		/* iterate through the remaining blue bit of the index so b holds the low two bits */
		for (i = 1; i < 2; i++) {
			b = b | ((index % 2) << i);
			index /= 2;
		}
		int g = index % 2;	/* set g to the thrid lowest bit of the index */
		index /= 2;	/* divide index by two to shift */
		/* iterate through the remaining green bit of the index so g holds the middle two bits */
		for (i = 1; i < 2; i++) {
			g = g | ((index % 2) << i);
			index /= 2;
		}
		int r = index % 2;	/* set r to the fifth lowest bit of the index */
		index /= 2;	/* divide index by two to shift */
		/* iterate through the remaining red bit of the index so r holds the highest two bits */
		for (i = 1; i < 2; i++) {
			r = r | ((index % 2) << i);
			index /= 2;
		}
		return ((b << 3) | (g << 9) | (r << 14));	/* return the values ORed together to get RR000:GG0000:BB000 */
 	}
	else {
		/* if the input is not in range, return -1 */
		return -1;
	}
}

/* 
 * populate_level_four
 *   DESCRIPTION: Given an array of octree nodes, this function fills the array with 4096 level
 *				  four octree nodes whose values are calculated based on their index with the
 *				  get_value_four function, and all other variables set to 0.
 *   INPUTS: oct -- array of octree nodes to populate
 *   OUTPUTS: none
 *   RETURN VALUE: none
 *   SIDE EFFECTS: fills octree with nodes with values calculated using the get_value_four function
 */
void populate_level_four(struct oct_node_t* oct) {
	int num_level_four = 4096;	/* number of level four octree nodes */
	int i = 0;
	/* iterate through 4096 indexes of the array */
	for (i = 0; i < num_level_four; i++) {
		/* initialize an octree node with the value calculated base on index, and all other variables set to 0 */
		struct oct_node_t cur = {.value = get_value_four(i), .frequency = 0, .r = 0, .g = 0, .b = 0, .r_two = 0, .g_two = 0, .b_two = 0};
		oct[i] = cur;	/* set the current octree node in the array to the initialized node */
	}
	return;
}

/* 
 * populate_level_two
 *   DESCRIPTION: Given an array of octree nodes, this function fills the array with 64 level
 *				  two octree nodes whose values are calculated based on their index with the
 *				  get_value_two function, and all other variables set to 0.
 *   INPUTS: oct -- array of octree nodes to populate
 *   OUTPUTS: none
 *   RETURN VALUE: none
 *   SIDE EFFECTS: fills octree with nodes with values calculated using the get_value_two function
 */
void populate_level_two(struct oct_node_t* oct) {
	int num_level_two = 64;	/* number of level two octree nodes */
	int i = 0;
	/* iterate through 64 indexes of the array */
	for (i = 0; i < num_level_two; i++) {
		/* initialize an octree node with the value calculated base on index, and all other variables set to 0 */
		struct oct_node_t cur = {.value = get_value_two(i), .frequency = 0, .r = 0, .g = 0, .b = 0, .r_two = 0, .g_two = 0, .b_two = 0};
		oct[i] = cur;	/* set the current octree node in the array to the initialized node */
	}
	return;
}

/* 
 * value_to_index
 *   DESCRIPTION: Given a RRRRR:GGGGGG:BBBBB value, this function calculates and returns
 *				  the corresponding level four index in the format RRRR:GGGG:BBBB.
 *   INPUTS: value -- value to be converted to level four index
 *   OUTPUTS: none
 *   RETURN VALUE: the RRRR:GGGG:BBBB index corresponding to the input value
 *   SIDE EFFECTS: none
 */
int value_to_index(int value) {
	int max_value = 63390;	/* maximum value a level four octree node can have */
	/* check if the value is within the range of level four octree node values */
	if (value > 0 && value <= max_value) {
		/* if it is, get the first four bits of the red, green, and blue values from the value*/
		int r = (value & 0x0F000) >> 4;
		int g = (value & 0x780) >> 3;
		int b = (value & 0x1E) >> 1;
		return (r | g | b);	/* return the four bit values ORed together */
	}
	else {
		/* if the input is not within range, return -1 */
		return -1;
	}
}

/* 
 * comp
 *   DESCRIPTION: Given two octree nodes, this function calculates and returns the
 *				  difference between their frequencies.
 *   INPUTS: a, b -- the two octree nodes to compare
 *   OUTPUTS: none
 *   RETURN VALUE: the difference between the frequencies
 *   SIDE EFFECTS: none
 */
int comp(const void* a, const void* b) {
	/* return the difference between the frequencies of the input octrees */
	return ((*(struct oct_node_t*)b).frequency - (*(struct oct_node_t*)a).frequency);
}
