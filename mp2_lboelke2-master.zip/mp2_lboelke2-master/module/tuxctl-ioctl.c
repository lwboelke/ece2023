/* tuxctl-ioctl.c
 *
 * Driver (skeleton) for the mp2 tuxcontrollers for ECE391 at UIUC.
 *
 * Mark Murphy 2006
 * Andrew Ofisher 2007
 * Steve Lumetta 12-13 Sep 2009
 * Puskar Naha 2013
 */

#include <asm/current.h>
#include <asm/uaccess.h>

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/file.h>
#include <linux/miscdevice.h>
#include <linux/kdev_t.h>
#include <linux/tty.h>
#include <linux/spinlock.h>

#include "tuxctl-ld.h"
#include "tuxctl-ioctl.h"
#include "mtcp.h"

#define debug(str, ...) \
	printk(KERN_DEBUG "%s: " str, __FUNCTION__, ## __VA_ARGS__)

static int flag = 0;	/* keeps track of if the device has completed a command and is ready for another */

static int button_val = 0xFFFFFFFF;	/* used to hold the current state of the buttons */

static unsigned long init_state = 0;	/* state to initialize the LEDS to (all off) */

static unsigned long prev_state = 0;	/* keeps track of the previous LED state so it can be restored */

/************************ Protocol Implementation *************************/

/* tuxctl_handle_packet()
 * IMPORTANT : Read the header for tuxctl_ldisc_data_callback() in 
 * tuxctl-ld.c. It calls this function, so all warnings there apply 
 * here as well.
 */
void tuxctl_handle_packet (struct tty_struct* tty, unsigned char* packet)
{
    unsigned a, b, c;

    a = packet[0]; /* Avoid printk() sign extending the 8-bit */
    b = packet[1]; /* values when printing them. */
    c = packet[2];

	/* check the opcode of the packet to determine what should be done */
	switch(a) {
		/* if the opcode is MTCP_RESET */
		case MTCP_RESET:
			init_helper(tty);	/* re-initialize variables associated with the driver */
			led_helper(tty, prev_state);	/* set LEDs to their previous state */
			break;
		/* otherwise, if the opcode is MTCP_BIOC_EVENT */
		case MTCP_BIOC_EVENT:
			button_val = ((b & 0x0F) | ((c & 0x08) << 4) | ((c & 0x01) << 4) | ((c & 0x02) << 5) | ((c & 0x04) << 3));	/* set button_val to the current status of the buttons from the packet */
			break;
		/* otherwise, if the opcode is MTCP_ACK */
		case MTCP_ACK:
			flag = 0;	/* a command was successfully completed, so set flag back to zero */
			break;
		/* otherwise, do nothing */
		default:
			return;
	}

    /*printk("packet : %x %x %x\n", a, b, c); */
}

/******** IMPORTANT NOTE: READ THIS BEFORE IMPLEMENTING THE IOCTLS ************
 *                                                                            *
 * The ioctls should not spend any time waiting for responses to the commands *
 * they send to the controller. The data is sent over the serial line at      *
 * 9600 BAUD. At this rate, a byte takes approximately 1 millisecond to       *
 * transmit; this means that there will be about 9 milliseconds between       *
 * the time you request that the low-level serial driver send the             *
 * 6-byte SET_LEDS packet and the time the 3-byte ACK packet finishes         *
 * arriving. This is far too long a time for a system call to take. The       *
 * ioctls should return immediately with success if their parameters are      *
 * valid.                                                                     *
 *                                                                            *
 ******************************************************************************/
int 
tuxctl_ioctl (struct tty_struct* tty, struct file* file, 
	      unsigned cmd, unsigned long arg)
{
    switch (cmd) {
	/* if cmd is TUX_INIT */
	case TUX_INIT:
		init_helper(tty);	/* initialize the variables */
		led_helper(tty, init_state);	/* initialize the LEDs to all off */
		return 0;
	/* otherwise, if cmd is TUX_BUTTONS */
	case TUX_BUTTONS:
		buttons_helper(arg);	/* set the buttons to button_val */
		return 0;
	/* otherwise, if cmd is TUX_SET_LED */
	case TUX_SET_LED:
		led_helper(tty, arg);	/* set the LEDs to the value from arg */
		return 0;
	/* in all other cases of valid input, return -1 */
	case TUX_LED_ACK:
		return -1;
	case TUX_LED_REQUEST:
		return -1;
	case TUX_READ_LED:
		return -1;
	/* in the case of invalid input, return -EINVAL */
	default:
	    return -EINVAL;
    }
}

/* 
 * init_helper
 *   DESCRIPTION: This helper function initializes variables associated with the driver,
 *				  by enabling Button interrupt-on-change and putting the led display into
 *				  user-mode.
 *   INPUTS: tty -- the tty to pass as an argument to tuxctl_ldisc_put
 *   OUTPUTS: none
 *   RETURN VALUE: always returns 0
 *   SIDE EFFECTS: enables Button interrupt-on-change, and puts the led display into user-mode
 */
int init_helper(struct tty_struct* tty) {
	char buf[2];	/* initialize a buffer of size two */
	buf[0] = MTCP_BIOC_ON;	/* set the first element in the buffer to MTCP_BIOC_ON to enable Button interrupt-on-change */
	buf[1] = MTCP_LED_USR;	/* set the second element in the buffer to MTCP_LED_USR to put the led display into user-mode */
	tuxctl_ldisc_put(tty, buf, 2);	/* call put with the buffer as an argument */
	return 0;
}

/* 
 * buttons_helper
 *   DESCRIPTION: Given a pointer to a 32-bit integer, this helper function writes the
 *				  current status of the buttons to the low byte to the 32-bit integer.
 *   INPUTS: arg -- a pointer to the 32-bit integer to write to
 *   OUTPUTS: none
 *   RETURN VALUE: returns 0 on success, -1 if copy_to_user failed, or -EINVAL if input
 *				   is invalid
 *   SIDE EFFECTS: sets the low byte of the 32-bit integer to the values of the buttons
 */
int buttons_helper(unsigned long arg) {
	int ret;	/* to hold the return value of copy_to_user */
	/* check if the argument is NULL, and if it is return -EINVAL */
	if ((int*)arg == NULL) {return -EINVAL;}
	ret = copy_to_user((int*)arg, (int*)&button_val, 4);	/* set the low byte of the int pointed to by arg to the value of button_val */
	/* check if copy_to_user returned a non-zero value, and if it did return -1 */
	if (ret != 0) {return -1;}
	return 0;	/* otherwise, return 0 */
}

/* 
 * led_helper
 *   DESCRIPTION: Given a 32-bit int with data for which decimal points should be
 *				  on, which LEDs should be on, and what value should be displayed
 *				  by the LEDs, this function sets the LEDs to that value.
 *   INPUTS: tty -- the tty to pass as an argument to tuxctl_ldisc_put
 *			 arg -- the data for which decimal points and LEDs should be on, and the value
 *					to set the LEDs to
 *   OUTPUTS: none
 *   RETURN VALUE: always returns 0
 *   SIDE EFFECTS: sets the LEDs to the based on value from arg
 */
int led_helper(struct tty_struct* tty, unsigned long arg) {
	int num_leds = 4;	/* number of LEDs on the display */
	int buffer_size = 6;	/* size of the buffer to pass to tuxctl_ldisc_put */
	int value = (arg & 0x0FFFF);	/* get the value for the LEDs from the last 16 bits of arg */
	int leds[num_leds];	/* to hold the value for each LED */	
	int dps = ((arg & 0x0F000000) >> 24);	/* get the bitmask for which decimal points are on */
	int dec_pts[num_leds];	/* to hold the value for each decimal point (0 or 1 for off or on) */
	int bit_mask = ((arg & 0x000F0000) >> 16);	/* get the bitmask for which LEDs are on */
	int mask_copy = bit_mask;	/* make a copy of the bitmask to be used to set leds_on array */
	int led_on[num_leds];	/* to hold which LEDs are on (0 or 1 for off or on) */
	char buf[buffer_size];	/* buffer to pass as an argument to tuxctl_ldisc_put */
	int i = 0;
	/* check if the device has not completed the previous command, and if it has not return 0 */
	if (flag == 1) {return 0;}
	prev_state = arg;	/* if it has, set the previous state of LEDs to arg */
	/* iterate through the decimal point bitmask and populate dec_pts accordingly */
	for (i = 0; i < num_leds; i++) {
		dec_pts[i] = (dps & 1);
		dps = dps >> 1;
	}
	/* iterate through the 16-bit value and populate leds accordingly */
	for (i = 0; i < num_leds; i++) {
		leds[i] = (value & 0x0F);
		value = value >> 4;
	}
	/* iterate through the LED bitmask and populate led_on accordingly */
	for (i = 0; i < num_leds; i++) {
		led_on[i] = (mask_copy & 1);
		mask_copy = mask_copy >> 1;
	}
	buf[0] = MTCP_LED_SET;	/* set the first element in the buffer to opcode MTCP_LED_SET */
	buf[1] = 0x0F;	/* set all of the LEDs to on so buffer can always be size 6 */
	/* get the data for the four remaining buffer elements */
	for (i = 0; i < num_leds; i++) {
		char byte = 0;
		/* if the decimal point is on, set dp bit to 1 in current byte */
		if (dec_pts[i] == 1) {
			byte = (byte | 0x010);
		}
		/* if the LED is not on, set the current buffer element to 0 so LED is off */
		if (led_on[i] == 0) {
			buf[i + 2] = (char)0;
			continue;
		}
		/* depending on what the value of the current LED is, set byte to the corresponding LED segment values */
		switch(leds[i]) {
			case 0x0:
				byte = (byte | 0x0E7);	/* 0 on LED */
				break;
			case 0x1:
				byte = (byte | 0x06);	/* 1 on LED */
				break;
			case 0x2:
				byte = (byte | 0x0CB);	/* 2 on LED */
				break;
			case 0x3:
				byte = (byte | 0x08F);	/* 3 on LED */
				break;
			case 0x4:
				byte = (byte | 0x02E);	/* 4 on LED */
				break;
			case 0x5:
				byte = (byte | 0x0AD);	/* 5 on LED */
				break;
			case 0x6:
				byte = (byte | 0x0ED);	/* 6 on LED */
				break;
			case 0x7:
				byte = (byte | 0x086);	/* 7 on LED */
				break;
			case 0x8:
				byte = (byte | 0x0EF);	/* 8 on LED */
				break;
			case 0x9:
				byte = (byte | 0x0AF);	/* 9 on LED */
				break;
			case 0xA:
				byte = (byte | 0x0EE);	/* A on LED */
				break;
			case 0xB:
				byte = (byte | 0x0EF);	/* B on LED */
				break;
			case 0xC:
				byte = (byte | 0x0E1);	/* C on LED */
				break;
			case 0xD:
				byte = (byte | 0x0E7);	/* D on LED */
				break;
			case 0xE:
				byte = (byte | 0x0E9);	/* E on LED */
				break;
			case 0xF:
				byte = (byte | 0x0E8);	/* F on LED */
				break;
			/* if it is none of the above, something is wrong so set LED to off */
			default:
				byte = (byte | 0x00);
		}
		buf[i + 2] = (char)byte;	/* set the current buffer element to the segment byte from above */
	}
	tuxctl_ldisc_put(tty, buf, buffer_size);	/* set the LEDs using the buffer we created */
	flag = 1;	/* set the flag to 1 so that we wait until device is ready before changing LEDs again */
	return 0;
}

